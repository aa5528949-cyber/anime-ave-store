import React, { useState } from 'react'
import Header from './components/Header'
import ProductList from './components/ProductList'

export default function App() {
  const [search, setSearch] = useState('')
  return (
    <div>
      <Header search={search} setSearch={setSearch} />
      <ProductList search={search} />
    </div>
  )
}
