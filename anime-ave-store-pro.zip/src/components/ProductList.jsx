import React from 'react'
import ProductCard from './ProductCard'

const products = [
  {
    id: 1,
    name: 'Attack on Titan Hoodie',
    price: 39.99,
    image: 'https://via.placeholder.com/200x250?text=AoT+Hoodie'
  },
  {
    id: 2,
    name: 'Naruto Kunai Set',
    price: 24.99,
    image: 'https://via.placeholder.com/200x250?text=Kunai+Set'
  },
  {
    id: 3,
    name: 'One Piece Straw Hat',
    price: 19.99,
    image: 'https://via.placeholder.com/200x250?text=Straw+Hat'
  },
  {
    id: 4,
    name: 'Gojo Satoru Figure',
    price: 89.99,
    image: 'https://via.placeholder.com/200x250?text=Gojo+Figure'
  }
]

export default function ProductList({ search }) {
  const filtered = products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '2rem', padding: '2rem' }}>
      {filtered.length > 0 ? filtered.map(product => (
        <ProductCard key={product.id} {...product} />
      )) : <p>No products found.</p>}
    </div>
  )
}
