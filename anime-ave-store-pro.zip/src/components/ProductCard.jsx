import React from 'react'

export default function ProductCard({ name, price, image }) {
  return (
    <div style={{
      border: '1px solid #ccc',
      borderRadius: '10px',
      padding: '1rem',
      width: '200px',
      textAlign: 'center'
    }}>
      <img src={image} alt={name} style={{ width: '100%', height: '250px', objectFit: 'cover' }} />
      <h3>{name}</h3>
      <p>${price}</p>
      <button style={{
        padding: '0.5rem 1rem',
        background: '#000',
        color: '#fff',
        border: 'none',
        borderRadius: '5px',
        cursor: 'pointer'
      }}>Add to Cart</button>
    </div>
  )
}
