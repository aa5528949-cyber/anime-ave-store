import React from 'react'

export default function Header({ search, setSearch }) {
  return (
    <header style={{ padding: '1rem', background: '#000', color: '#fff' }}>
      <h1 style={{ textAlign: 'center' }}>Anime Ave</h1>
      <p style={{ textAlign: 'center' }}>Your ultimate anime merch store</p>
      <div style={{ textAlign: 'center', marginTop: '1rem' }}>
        <input
          type="text"
          placeholder="Search products..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{
            padding: '0.5rem',
            width: '60%',
            maxWidth: '400px',
            borderRadius: '8px',
            border: '1px solid #ccc'
          }}
        />
      </div>
    </header>
  )
}
